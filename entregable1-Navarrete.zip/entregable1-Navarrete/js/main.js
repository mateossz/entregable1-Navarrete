
function Burger(precio, descripcion) {
    this.precio = precio;
    this.descripcion = descripcion;
}


const simple = new Burger(12000, 'un medallon de carne, dos fetas de cheddar y bacon');
const doble = new Burger(14000, 'dos medallones de carne, cuatro fetas de cheddar, bacon y cebolla caramelizada');
const triple = new Burger(15000, 'tres medallones de carne, seis fetas de cheddar, bacon, cebolla caramelizada y huevo');

let verificacion = prompt('Hola! ¿Tenés una cuenta? si/no');

// SIGNUP
if (verificacion === 'no') {

  let nuevoUsuario = prompt('Creá tu usuario');
  let nuevaPassword = prompt('Creá tu contraseña');

  localStorage.setItem('usuario', nuevoUsuario);
  localStorage.setItem('password', nuevaPassword);

  alert('Cuenta creada y guardada correctamente');
}

// LOGIN
let usuarioGuardado = localStorage.getItem('usuario');
let passwordGuardada = localStorage.getItem('password');

let usuario = prompt("Ingresá tu usuario");
let password = prompt("Ingresá tu contraseña");

if (usuario === usuarioGuardado && password === passwordGuardada) {

  alert('Bienvenido ' + usuario);

  let salirMenu = false;

  while (!salirMenu) {

    let menu = prompt('Hamburgueseria Mateo \n1 - Ubicación \n2 - Horarios \n3 - Hacer pedido \n4 - Finalizar \nElegí una opción');

    if (menu == '1') {

      alert('Nos encontramos en Godoy Cruz, Mendoza');

    } else if (menu == '2') {

      alert('Nuestros horarios son de 19:00 a 01:00');

    } else if (menu == "3") {

      let total = 0;
      let carrito = [];
      let continuar = true;

      while (continuar) {

        let opcion = prompt('MENU BURGERS  \n1 - Simple ($12000) \n2 - Doble ($14000) \n3 - Triple ($15000) \nElegí una burger');

        let cantidad = Number(prompt('¿Cuántas querés?'));

        while (!Number.isInteger(cantidad) || cantidad <= 0) {
          cantidad = Number(prompt('Ingresá un número entero positivo'));
        }

        if (opcion == '1') {
          total += simple.precio * cantidad;
          carrito.push("Simple x" + cantidad);
        } 
        else if (opcion == '2') {
          total += doble.precio * cantidad;
          carrito.push("Doble x" + cantidad);
        } 
        else if (opcion == '3') {
          total += triple.precio * cantidad;
          carrito.push("Triple x" + cantidad);
        } 
        else {
          alert('Opción inválida');
        }

        let seguir = prompt('¿Querés agregar otra burger? si/no');

        if (seguir !== 'si') {
          continuar = false;
        }
      }

      console.log('----- TICKET DE COMPRA -----');

      for (let item of carrito) {
        console.log(item);
      }

      console.log("----------------------------");
      console.log("Total: $" + total);
      let metodoPago = prompt('¿Cómo vas a abonar? \n 1 - Efectivo\n 2 - Transferencia\n 3 - Combinado');

        if (metodoPago == '1') {

          console.log('Método de pago: Efectivo');

        } else if (metodoPago == '2') {

          console.log('Método de pago: Transferencia');

        } else if (metodoPago == '3') {

          let efectivo = Number(prompt('¿Cuánto pagás en efectivo?'));
          let transferencia = total - efectivo;

          console.log('Pago combinado:');
          console.log('Efectivo: $' + efectivo);
          console.log('Transferencia: $' + transferencia);

        } else {

          console.log('Método de pago no válido');

        }

    } else if (menu == '4') {

      salirMenu = true;
      alert('Gracias por visitar a la Hamburgueseria Mateo!');

    } else {

      alert('Opción inválida');

    }

  }
}